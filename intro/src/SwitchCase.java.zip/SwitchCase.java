
public class SwitchCase {
	public static void main( String args[]){
	char value = 'D';
		switch(value)
		{
		case 'A':
			System.out.println("100-80");
			break;
		case 'B':
			System.out.println("73-79");
			break;
		default:
			System.out.println("marks is not available");
			break;
		}
			
	}
}
